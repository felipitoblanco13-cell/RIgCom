/* 
 * RIGFACE · Canonical Master Integration Header
 * Complete Master Contract for 95 Logical Files (58 ZIP 1 + 37 ZIP 2)
 * Platform: Honor 400 DNY-NX9 (Snapdragon 7 Gen 3 / Adreno 720 / Android 16)
 * Architect: Richard Felipe Urbina
 */

#ifndef RIG_FACE_MASTER_H
#define RIG_FACE_MASTER_H

#include "rig_aom_physical.h"
#include "rig_face_session.h"

#define RIG_FACE_TOTAL_FILES 95
#define RIG_FACE_ZIP1_FILES  58
#define RIG_FACE_ZIP2_FILES  37

/* -------------------------------------------------------------------------
 * SECTION 1: Master Orchestration & Entry Points
 * ------------------------------------------------------------------------- */

typedef struct {
    RigSovereignSession session;
    bool camera_active;
    bool audio_active;
    bool ultrasonic_active;
    bool webgl_portal_active;
} RigFaceStudioMaster;

/* Main Orchestration Entry Points */
void rig_face_master_init(RigFaceStudioMaster *studio, const char *project_name);
void rig_face_master_step_frame(RigFaceStudioMaster *studio, float dt_sec);
void rig_face_master_process_touch(RigFaceStudioMaster *studio, float screen_x, float screen_y, float force);

/* -------------------------------------------------------------------------
 * SECTION 2: Sub-module Function Declarations (A - N)
 * ------------------------------------------------------------------------- */

/* Module A: Facial Creation & Anatomy */
void rig_face_create_neutral_mesh(RigSovereignSession *s);
void rig_face_subdivide_loop(RigSovereignSession *s, uint8_t level);

/* Module B: Archetypes & Genetics (36 Archetypes, 48 Genome Traits) */
void rig_face_genetics_init(RigSovereignSession *s);
void rig_face_genetics_blend(RigSovereignSession *s, const char *arch_a, const char *arch_b, float weight);
void rig_face_genetics_pca_project(RigSovereignSession *s);

/* Module C: Scanning & Reconstruction (Camera V4L2 / Honor 400 Native) */
void rig_face_camera_init_honor400(void);
void rig_face_vision_track_68_points(const uint8_t *frame_yuyv, float points_out[68][2]);
void rig_face_recon_bridge_build_mesh(const float points[68][2], RigSovereignSession *s);

/* Module D: Living Skin (8-layer Spectral Skin, Chromophores, Vessels, Wrinkles) */
void rig_face_skin_generate_textures(RigSovereignSession *s);
void rig_face_dermal_update_pulse(RigSovereignSession *s, float bpm);
void rig_face_dermal_apply_aging(RigSovereignSession *s, float age);

/* Module E: Hair & Follicle Growth (Marschner / Chiang Model, Bézier Strands) */
void rig_face_hair_init_follicles(RigSovereignSession *s, uint32_t count);
void rig_face_hair_simulate_physics(RigSovereignSession *s, float wind_vector[3]);

/* Module F: Biophysical Eyes & Vision (Vergence, Accommodation, Purkinje, SSS) */
void rig_face_eye_vergence_compute(RigSovereignSession *s, const float target_3d[3]);
void rig_face_eye_update_refraction(RigSovereignSession *s);

/* Module G: Mouth, Lips & Dentition */
void rig_face_dentition_build_arches(RigSovereignSession *s);
void rig_face_dentition_update_viseme(RigSovereignSession *s, uint8_t viseme_id);

/* Module H: Voice, Audio & Facial Animation (128 AU, 43 Muscles, Glottal Synth) */
void rig_face_audio_analyze_frame(const int16_t *pcm_input, uint32_t samples, float au_out[128]);
void rig_face_voice_synth_phonemes(const char *phoneme_script, int16_t *pcm_out, uint32_t *samples_out);
void rig_voz_express_state(const char *state_name, int16_t *pcm_out);

/* Module I: Body, Pose & Secondary Soft Body Physics */
void rig_face_body_build_capsules(RigSovereignSession *s);
void rig_face_soft_body_update(RigSovereignSession *s, float dt);
void rig_face_cloth_simulate(RigSovereignSession *s, float dt);

/* Module J: Materials, Environment & PBR Rendering (34 Presets, GGX, Path Trace) */
void rig_material_set_preset(RigSovereignSession *s, const char *preset_name);
void rig_env_update_lighting(RigSovereignSession *s, float kelvin_temp, float sun_dir[3]);
void rig_pathtrace_render_frame(RigSovereignSession *s, uint32_t *pixel_buffer_out);

/* Module K: Touch, AOM & Material Sound Synthesis */
void rig_aom_synthesize_triple_output(RigSovereignSession *s, float touch_x, float touch_y);
void rig_parametric_audio_generate(RigSovereignSession *s, int16_t *pcm_out);
void rig_haptic_drive_matrix(RigSovereignSession *s);

/* Module L: RigArt Studio & Generative Shaders */
void rigart_v4_art_render_canvas(RigSovereignSession *s);
void rigart_v5_mobile_apply_template(RigSovereignSession *s, const char *template_name);

/* Module M: Sovereign Identity & Cryptographic Vault */
bool rig_identity_validate_curp(const char *curp);
bool rig_identity_validate_ine(const char *ine_cic);
void rig_identity_vault_store(RigSovereignIdentity *id, const char *key, const uint8_t *data, size_t len);

/* Module N: Export & Development CodeGen */
void rig_export_gltf_glb(RigSovereignSession *s, const char *filepath);
void rig_export_vrm(RigSovereignSession *s, const char *filepath);
void rig_export_arkit_json(RigSovereignSession *s, const char *filepath);
void rig_codegen_c11_headers(RigSovereignSession *s, const char *out_h_path);

#endif /* RIG_FACE_MASTER_H */
