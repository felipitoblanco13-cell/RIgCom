/* 
 * RIGFACE · Sovereign Session Core Header
 * Complete unified project state contract
 * Hardware Target: Honor 400 DNY-NX9 (Snapdragon 7 Gen 3 / Adreno 720)
 * Architect: Richard Felipe Urbina
 */

#ifndef RIG_FACE_SESSION_H
#define RIG_FACE_SESSION_H

#include <stdint.h>
#include <stdbool.h>
#include "rig_aom_physical.h"

#define RIG_FACE_GENOME_TRAITS 48
#define RIG_FACE_ARCHETYPES_COUNT 36
#define RIG_FACE_FACS_AU_COUNT 128
#define RIG_FACE_MUSCLES_COUNT 43

typedef enum {
    RIG_PROFILE_MODULAR = 0,
    RIG_PROFILE_CONSOLIDATED,
    RIG_PROFILE_CANONICAL,
    RIG_PROFILE_COMPARISON
} RigProfileMode;

/* 1. Identity & Cryptography Contract */
typedef struct {
    char curp[19];
    char ine_cic[10];
    char rfc[14];
    char passport_mrz[90];
    bool renapo_verified;
    bool user_consent_hmac;
    
    uint8_t ed25519_pk[32];
    uint8_t ed25519_sk[64];
    uint8_t x25519_pk[32];
    uint8_t phone_hash_sha256[32];
    
    char vault_path[256];
    bool vault_unlocked;
} RigSovereignIdentity;

/* 2. Genetics & Archetypes */
typedef struct {
    float traits[RIG_FACE_GENOME_TRAITS];
    char primary_archetype_name[64];
    uint8_t archetype_category_id;
    float archetype_blend_weights[RIG_FACE_ARCHETYPES_COUNT];
    
    float age_years;
    float age_timeline_key;
} RigGeneticsState;

/* 3. Anatomical Meshes & Skeleton */
typedef struct {
    uint32_t face_vertices_count;
    uint32_t body_vertices_count;
    uint32_t hair_strands_count;
    uint32_t teeth_count;
    
    float *face_vbo_ptr;
    float *body_vbo_ptr;
    float *hair_bezier_ptr;
    
    uint32_t bones_count;
    float *skeleton_matrices_ptr;
    float *dual_quaternion_weights_ptr;
    
    bool soft_body_enabled;
    bool cloth_simulation_enabled;
} RigAnatomyState;

/* 4. Dermal & Biophysical Skin State */
typedef struct {
    float melanin;
    float hemoglobin;
    float carotene;
    float epidermis_thickness_um;
    float dermis_thickness_um;
    
    uint32_t pores_count;
    uint32_t vascular_branches_count;
    float sweat_humidity;
    float goosebumps_level;
    float blush_level;
    float scars_count;
} RigDermalState;

/* 5. Biophysical Eyes & Vision */
typedef struct {
    float iris_hue;
    float pupil_dilation_mm;
    float gaze_target_3d[3];
    float vergence_yaw_pitch[2];
    float accommodation_dist_cm;
    float lens_blur_circle_mm;
    bool eye_tracking_active;
} RigEyeState;

/* 6. Dentition, Voice & Animation */
typedef struct {
    float facs_au[RIG_FACE_FACS_AU_COUNT];
    float muscle_activations[RIG_FACE_MUSCLES_COUNT];
    
    char current_phoneme[8];
    uint8_t viseme_id;
    
    float audio_pcm_energy;
    float formants_hz[5];
    
    bool arkit_52_blendshapes_valid;
    float arkit_coefficients[52];
} RigAnimationState;

/* 7. Unified Master Session Struct */
typedef struct {
    char project_id[64];
    char user_id[64];
    char avatar_id[64];
    
    RigProfileMode active_profile;
    RigSovereignIdentity identity;
    RigGeneticsState genetics;
    RigAnatomyState anatomy;
    RigDermalState dermal;
    RigEyeState eye;
    RigAnimationState animation;
    RigAomMasterState aom_physical;
    
    /* Event & Error Audit Log */
    uint32_t total_events_logged;
    uint32_t total_errors_logged;
} RigSovereignSession;

/* Session API */
void rig_session_init(RigSovereignSession *session, const char *project_id);
void rig_session_load_archetype(RigSovereignSession *session, const char *archetype_name);
void rig_session_apply_age(RigSovereignSession *session, float age_years);
void rig_session_update_audio_frame(RigSovereignSession *session, const int16_t *pcm_samples, uint32_t count);
void rig_session_export_all(RigSovereignSession *session, const char *output_dir);

#endif /* RIG_FACE_SESSION_H */
