# RIGFACE / RIGCOM — Proyecto C listo para compilar

Motor de rigging facial y corporal en C (95 módulos). Fuentes extraídos de los ZIPs originales, ordenados por procedencia. **Compilación verificada con gcc.**

## Estructura

- `master_zips/` — Estudio Soberano Master: motor maestro (`rig_face_master.c/.h`, `rig_master_sovereign_engine.c/.h`), tests, inventarios JSON/CSV, UI HTML. Binarios `.o` y ejecutables previos eliminados.
- `RIGFACE_C_UNIFICADO/` — 45 fuentes unificados (`src/`): engine, export ARKit/VRM, ojos, audio, archetypes, codegen.
- `plano_95/` — Los 95 archivos del plano completo.
- `arte/` — 63 archivos motor + arte: UI consola, voz, visión, hair/skin, rigart v4.

## Compilar y ejecutar (verificado)

```bash
make            # compila rig_engine y rig_test
./rig_engine   # RIGFACE Master Engine Initialized Successfully for Honor 400 DNY-NX9!
./rig_test     # Session initialized: 'RIGFACE-HONOR400-CANONICAL'
```

Sin make: `gcc -O2 -Wall master_zips/rig_master_sovereign_engine.c -o rig_engine`

## Notas

- Los 95 módulos del plano son semi-independientes (cabeceras con API común); no hay build unificado de los 95 todavía — este Makefile compila el núcleo soberano verificado.
- La versión web del ecosistema (RIGADIEL Studio) está en la carpeta `comet-pine-crystal-sand/` del paquete.
