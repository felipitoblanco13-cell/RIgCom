import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowRight,
  Cpu,
  GitBranch,
  Layers,
  Play,
  ShieldCheck,
  Terminal,
} from "lucide-react";
import { LANGS, R148, TESTS, EXAMPLES, translateCode, safeEval } from "@/lib/babel/engine";
import {
  CERTEZA,
  PHI,
  SAMPLE_C,
  SCHUMANN_NS,
  dump,
  loadOrganismo,
  type OrganismoApi,
} from "@/lib/organismo";

export const Route = createFileRoute("/")({ component: Studio });

type Tab = "ciclo" | "babel" | "compilar" | "verificar" | "reglas" | "pruebas";

const INTENTS = [
  { id: "analizar", label: "Analizar" },
  { id: "traducir", label: "Traducir" },
  { id: "compilar", label: "Compilar" },
  { id: "consultar", label: "Consultar" },
  { id: "verificar", label: "Verificar" },
] as const;

function Studio() {
  const [tab, setTab] = useState<Tab>("ciclo");
  const [org, setOrg] = useState<OrganismoApi | null>(null);
  const [orgState, setOrgState] = useState<"loading" | "ready" | "missing">("loading");
  const [src, setSrc] = useState(SAMPLE_C);
  const [lang, setLang] = useState("C");
  const [dest, setDest] = useState("Python");
  const [intent, setIntent] = useState<(typeof INTENTS)[number]["id"]>("analizar");
  const [target, setTarget] = useState("arm64");
  const [trace, setTrace] = useState("");
  const [rama, setRama] = useState<string>("—");
  const [busy, setBusy] = useState(false);
  const [babelFrom, setBabelFrom] = useState("JavaScript");
  const [babelTo, setBabelTo] = useState("Python");
  const [babelSrc, setBabelSrc] = useState(EXAMPLES.JavaScript);
  const [babelOut, setBabelOut] = useState("");
  const [babelLog, setBabelLog] = useState<ReturnType<typeof translateCode>["log"]>([]);
  const [ruleQ, setRuleQ] = useState("");
  const [testId, setTestId] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    loadOrganismo().then((api) => {
      if (!live) return;
      setOrg(api);
      setOrgState(api ? "ready" : "missing");
    });
    return () => {
      live = false;
    };
  }, []);

  const ruleStats = useMemo(() => {
    const active = R148.filter((r) => r.on === 1).length;
    return { total: R148.length, active, off: R148.length - active };
  }, []);

  const filteredRules = useMemo(() => {
    const q = ruleQ.trim().toLowerCase();
    if (!q) return R148;
    return R148.filter(
      (r) =>
        r.id.includes(q) ||
        r.cat.toLowerCase().includes(q) ||
        r.src.toLowerCase().includes(q) ||
        r.lang.toLowerCase().includes(q) ||
        r.dst.toLowerCase().includes(q) ||
        r.norm.toLowerCase().includes(q),
    );
  }, [ruleQ]);

  function runCiclo() {
    if (!org) {
      setRama("BLOQUEO");
      setTrace("BLOQUEO: organismo no cargado — el ciclo nativo no se simula.");
      return;
    }
    setBusy(true);
    try {
      const entrada: Record<string, unknown> = {
        src,
        intent,
        lang: lang === "C" ? "C" : lang,
        destino: dest,
        target,
      };
      const r = org.cicloVida(entrada) as Record<string, unknown>;
      setRama(String(r?.rama ?? "—"));
      setTrace(dump(r));
    } catch (e) {
      setRama("FAIL");
      setTrace(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  function runBabel() {
    const r = translateCode(babelSrc, babelFrom, babelTo);
    setBabelOut(r.out);
    setBabelLog(r.log);
  }

  function runOrgTranslate() {
    if (!org) {
      runBabel();
      return;
    }
    setBusy(true);
    try {
      const r = org.cicloVida({
        src: babelSrc,
        intent: "traducir",
        lang: babelFrom,
        destino: babelTo,
      });
      const rec = r as Record<string, unknown>;
      setRama(String(rec?.rama ?? "—"));
      const out =
        typeof rec.resultado === "string" ? rec.resultado : dump(r);
      setBabelOut(out);
      setTrace(dump(r));
    } catch (e) {
      setBabelOut(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  const tabs: { id: Tab; label: string; icon: typeof Activity }[] = [
    { id: "ciclo", label: "Ciclo de vida", icon: GitBranch },
    { id: "babel", label: "Traducir", icon: ArrowRight },
    { id: "compilar", label: "Compilar", icon: Cpu },
    { id: "verificar", label: "Verificar", icon: ShieldCheck },
    { id: "reglas", label: "Reglas 148", icon: Layers },
    { id: "pruebas", label: "10 pruebas", icon: Terminal },
  ];

  return (
    <main className="min-h-dvh bg-bg text-fg">
      <header className="border-b border-border bg-surface px-4 py-4 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono text-xs tracking-[0.22em] text-muted uppercase">
              RIGCOM · SOL-α
            </p>
            <h1 className="font-display text-2xl tracking-tight sm:text-3xl">
              RIGADIEL
            </h1>
            <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted">
              Un organismo. Percibe, veta, traduce, talla ARM64 y demuestra
              equivalencia. P(A) ∈ {"{0,1}"}. φ = {PHI}
            </p>
          </div>
          <div className="flex flex-wrap gap-2 font-mono text-[11px]">
            <Stat
              label="organismo"
              value={orgState === "ready" ? "vivo" : orgState === "loading" ? "despertando" : "ausente"}
              tone={orgState === "ready" ? "pass" : orgState === "missing" ? "fail" : "muted"}
            />
            <Stat label="certeza" value={String(CERTEZA)} />
            <Stat label="Schumann" value={`${SCHUMANN_NS} ns`} />
            <Stat label="Babel" value={`${ruleStats.active}/148`} tone="pass" />
          </div>
        </div>
      </header>

      <nav className="sticky top-0 z-10 border-b border-border bg-bg/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 py-2">
          {tabs.map((t) => {
            const Icon = t.icon;
            const on = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex min-h-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm transition-colors ${
                  on
                    ? "bg-accent text-accent-fg"
                    : "text-muted hover:bg-elevated hover:text-fg"
                }`}
              >
                <Icon className="size-4" />
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>

      <div className="mx-auto max-w-6xl px-4 py-5 sm:px-6">
        {tab === "ciclo" && (
          <Panel>
            <SectionTitle
              icon={GitBranch}
              title="cicloVida"
              hint="Puerta canónica del organismo. No se reinterpreta el objetivo."
            />
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="flex flex-col gap-3">
                <label className="text-xs text-muted">Fuente</label>
                <textarea
                  value={src}
                  onChange={(e) => setSrc(e.target.value)}
                  className="min-h-52 rounded-lg border border-border bg-elevated p-3 font-mono text-sm leading-relaxed text-fg outline-none focus:border-border-strong"
                />
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <Field label="Intento">
                    <select
                      value={intent}
                      onChange={(e) => setIntent(e.target.value as typeof intent)}
                      className="w-full rounded-sm border border-border bg-surface px-2 py-2 text-sm"
                    >
                      {INTENTS.map((i) => (
                        <option key={i.id} value={i.id}>
                          {i.label}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Lenguaje">
                    <select
                      value={lang}
                      onChange={(e) => setLang(e.target.value)}
                      className="w-full rounded-sm border border-border bg-surface px-2 py-2 text-sm"
                    >
                      {["C", ...LANGS].map((l) => (
                        <option key={l}>{l}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Destino">
                    <select
                      value={dest}
                      onChange={(e) => setDest(e.target.value)}
                      className="w-full rounded-sm border border-border bg-surface px-2 py-2 text-sm"
                    >
                      {LANGS.map((l) => (
                        <option key={l}>{l}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Target">
                    <select
                      value={target}
                      onChange={(e) => setTarget(e.target.value)}
                      className="w-full rounded-sm border border-border bg-surface px-2 py-2 text-sm"
                    >
                      {["arm64", "wasm", "elf64"].map((t) => (
                        <option key={t}>{t}</option>
                      ))}
                    </select>
                  </Field>
                </div>
                <button
                  onClick={runCiclo}
                  disabled={busy}
                  className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg disabled:opacity-50"
                >
                  <Play className="size-4" />
                  {busy ? "Ejecutando" : "Ejecutar ciclo"}
                </button>
              </div>
              <ResultCard rama={rama} trace={trace} empty="Sin traza. Ejecuta el ciclo." />
            </div>
          </Panel>
        )}

        {tab === "babel" && (
          <Panel>
            <SectionTitle
              icon={ArrowRight}
              title="Traducción mecánica"
              hint="148 reglas Babel (siempre vivas) · translatePerfect del organismo si está despierto."
            />
            <div className="mb-3 flex flex-wrap gap-2">
              <select
                value={babelFrom}
                onChange={(e) => {
                  setBabelFrom(e.target.value);
                  setBabelSrc(EXAMPLES[e.target.value] || babelSrc);
                }}
                className="min-h-11 rounded-sm border border-border bg-surface px-3 text-sm"
              >
                {LANGS.map((l) => (
                  <option key={l}>{l}</option>
                ))}
              </select>
              <span className="self-center text-muted">→</span>
              <select
                value={babelTo}
                onChange={(e) => setBabelTo(e.target.value)}
                className="min-h-11 rounded-sm border border-border bg-surface px-3 text-sm"
              >
                {LANGS.map((l) => (
                  <option key={l}>{l}</option>
                ))}
              </select>
              <button
                onClick={runBabel}
                className="min-h-11 rounded-lg border border-border-strong px-4 text-sm"
              >
                Babel 148
              </button>
              <button
                onClick={runOrgTranslate}
                className="min-h-11 rounded-lg bg-accent px-4 text-sm text-accent-fg"
              >
                Organismo SIR
              </button>
            </div>
            <div className="grid gap-3 lg:grid-cols-2">
              <textarea
                value={babelSrc}
                onChange={(e) => setBabelSrc(e.target.value)}
                className="min-h-64 rounded-lg border border-border bg-elevated p-3 font-mono text-sm"
              />
              <pre className="min-h-64 overflow-auto rounded-lg border border-border bg-elevated p-3 font-mono text-sm leading-relaxed whitespace-pre-wrap">
                {babelOut || "Salida de traducción."}
              </pre>
            </div>
            {babelLog.length > 0 && (
              <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
                {babelLog.map((l, i) => (
                  <li key={i}>
                    §{l.rid} {l.type} · {l.src} → {l.dst}
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        )}

        {tab === "compilar" && (
          <Panel>
            <SectionTitle
              icon={Cpu}
              title="Emisión nativa"
              hint="IR → ARM64 / WASM / ELF64. Frontends verificados: C, C++, Go, Kotlin, Rust, Swift, JS."
            />
            <textarea
              value={src}
              onChange={(e) => setSrc(e.target.value)}
              className="mb-3 min-h-40 w-full rounded-lg border border-border bg-elevated p-3 font-mono text-sm"
            />
            <div className="mb-3 flex flex-wrap gap-2">
              {["arm64", "wasm", "elf64"].map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    setTarget(t);
                    setIntent("compilar");
                    setLang("C");
                    setTab("ciclo");
                    setTimeout(() => {
                      setTarget(t);
                    }, 0);
                  }}
                  className="min-h-11 rounded-lg border border-border px-4 text-sm hover:bg-elevated"
                >
                  {t}
                </button>
              ))}
              <button
                onClick={() => {
                  setIntent("compilar");
                  setLang("C");
                  runCiclo();
                }}
                className="min-h-11 rounded-lg bg-accent px-4 text-sm text-accent-fg"
              >
                Compilar ahora
              </button>
            </div>
            <p className="text-sm text-muted">
              Python / Java / C# / Lua / Zig no se ofrecen como frontend AArch64:
              el propio motor los marcó incompletos (emisor vacío o stub). No se
              finge un backend.
            </p>
            <ResultCard rama={rama} trace={trace} empty="Compila para ver asm / WAT / ELF." />
          </Panel>
        )}

        {tab === "verificar" && (
          <Panel>
            <SectionTitle
              icon={ShieldCheck}
              title="RigVerifier"
              hint="Equivalencia comportamental origen vs destino. Sin PASS inventado."
            />
            <p className="mb-3 text-sm leading-relaxed text-muted">
              El ciclo con intento «traducir» corre Verifier. Si el organismo no
              está vivo, no se afirma equivalencia bit a bit.
            </p>
            <button
              onClick={() => {
                setIntent("traducir");
                setLang("C");
                setDest("Python");
                runCiclo();
              }}
              className="mb-4 min-h-11 rounded-lg bg-accent px-4 text-sm text-accent-fg"
            >
              Traducir C → Python y verificar
            </button>
            <ResultCard rama={rama} trace={trace} empty="Sin verificación aún." />
          </Panel>
        )}

        {tab === "reglas" && (
          <Panel>
            <SectionTitle
              icon={Layers}
              title="Tablas normativas"
              hint="Inventario real, no el número 967: no aparece en ningún archivo ingerido."
            />
            <div className="mb-4 grid gap-2 sm:grid-cols-3">
              <CountCard n="148" label="Babel R148 (143 activas, 5 deprecadas)" />
              <CountCard n="114+21" label="NORM_TABLE + V2 en el organismo" />
              <CountCard n="67" label="Canon v18 (superseded por las tablas JS)" />
            </div>
            <p className="mb-3 text-sm text-muted">
              FALTANTE: 967 reglas. No hay ese conteo en RIGADIEL_FINAL ni en los
              bundles. Lo que existe se lista abajo sin rellenar.
            </p>
            <input
              value={ruleQ}
              onChange={(e) => setRuleQ(e.target.value)}
              placeholder="Buscar id, constructo, lenguaje, NORM…"
              className="mb-3 min-h-11 w-full rounded-lg border border-border bg-elevated px-3 text-sm"
            />
            <p className="mb-2 font-mono text-xs text-subtle">
              {filteredRules.length}/{ruleStats.total}
            </p>
            <div className="flex max-h-[28rem] flex-col gap-1 overflow-auto pr-1">
              {filteredRules.map((r) => (
                <div
                  key={r.id}
                  className={`rounded-md border border-border bg-surface px-3 py-2 ${r.on ? "" : "opacity-40"}`}
                >
                  <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] text-muted">
                    <span className="text-accent">§{r.id}</span>
                    <span>{r.lang}</span>
                    <span>{r.norm}</span>
                    {!r.on && <span>DEPRECADA</span>}
                  </div>
                  <div className="mt-1 text-sm">
                    <span className="font-mono">{r.src}</span>
                    <span className="mx-2 text-subtle">→</span>
                    <span className="text-muted">{r.dst}</span>
                  </div>
                  <div className="text-xs text-subtle">{r.cat}</div>
                </div>
              ))}
            </div>
          </Panel>
        )}

        {tab === "pruebas" && (
          <Panel>
            <SectionTitle
              icon={Terminal}
              title="Diez casos Babel"
              hint="Traza semántica lenguaje-neutro. Ejecución JS cuando aplica."
            />
            <div className="space-y-2">
              {TESTS.map((tc) => {
                const open = testId === tc.id;
                return (
                  <div key={tc.id} className="rounded-lg border border-border bg-surface">
                    <button
                      onClick={() => setTestId(open ? null : tc.id)}
                      className="flex min-h-11 w-full items-center gap-3 px-3 text-left"
                    >
                      <span className="font-mono text-xs text-muted">{tc.id}</span>
                      <span className="flex-1 text-sm">{tc.name}</span>
                      <span className="text-xs text-subtle">{open ? "▾" : "▸"}</span>
                    </button>
                    {open && (
                      <div className="border-t border-border px-3 py-3">
                        <p className="mb-2 text-sm text-muted">{tc.desc}</p>
                        <p className="mb-2 font-mono text-xs text-pass">
                          Esperado: {tc.output}
                        </p>
                        <div className="mb-2 flex flex-wrap gap-1">
                          {tc.rids.map((id) => (
                            <span
                              key={id}
                              className="rounded-xs bg-elevated px-1.5 py-0.5 font-mono text-[10px] text-muted"
                            >
                              §{id}
                            </span>
                          ))}
                        </div>
                        <pre className="overflow-auto rounded-md bg-elevated p-3 font-mono text-xs leading-relaxed">
                          {tc.codes[babelFrom] || tc.codes.JavaScript}
                        </pre>
                        {babelFrom === "JavaScript" && tc.codes.JavaScript && (
                          <pre className="mt-2 rounded-md bg-elevated p-2 font-mono text-xs text-pass">
                            {safeEval(tc.codes.JavaScript).output}
                          </pre>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </Panel>
        )}
      </div>
    </main>
  );
}

function Panel({ children }: { children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-border bg-surface p-4 sm:p-5">
      {children}
    </section>
  );
}

function SectionTitle({
  icon: Icon,
  title,
  hint,
}: {
  icon: typeof Activity;
  title: string;
  hint: string;
}) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-2">
        <Icon className="size-4 text-muted" />
        <h2 className="font-display text-lg">{title}</h2>
      </div>
      <p className="mt-1 text-sm text-muted">{hint}</p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1 text-xs text-muted">
      {label}
      {children}
    </label>
  );
}

function Stat({
  label,
  value,
  tone = "muted",
}: {
  label: string;
  value: string;
  tone?: "muted" | "pass" | "fail";
}) {
  const color =
    tone === "pass" ? "text-pass" : tone === "fail" ? "text-fail" : "text-muted";
  return (
    <div className="rounded-md border border-border bg-elevated px-2.5 py-1.5">
      <div className="text-[10px] tracking-wide text-subtle uppercase">{label}</div>
      <div className={`text-xs ${color}`}>{value}</div>
    </div>
  );
}

function CountCard({ n, label }: { n: string; label: string }) {
  return (
    <div className="rounded-lg border border-border bg-elevated p-3">
      <div className="font-display text-xl">{n}</div>
      <div className="text-xs leading-snug text-muted">{label}</div>
    </div>
  );
}

function ResultCard({
  rama,
  trace,
  empty,
}: {
  rama: string;
  trace: string;
  empty: string;
}) {
  const tone =
    rama === "PASS" || rama === "vivo"
      ? "text-pass"
      : rama === "FAIL" || rama === "VETO" || rama === "BLOQUEO"
        ? "text-fail"
        : "text-muted";
  return (
    <div className="flex min-h-52 flex-col rounded-lg border border-border bg-elevated">
      <div className="flex items-center justify-between border-b border-border px-3 py-2">
        <span className="font-mono text-[11px] text-subtle uppercase">traza</span>
        <span className={`font-mono text-xs ${tone}`}>{rama}</span>
      </div>
      <pre className="flex-1 overflow-auto p-3 font-mono text-[11px] leading-relaxed whitespace-pre-wrap text-fg/90">
        {trace || empty}
      </pre>
    </div>
  );
}
