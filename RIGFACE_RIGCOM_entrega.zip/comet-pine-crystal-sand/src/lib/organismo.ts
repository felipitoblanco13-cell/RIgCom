export const PHI = 1.618033988749895;
export const SCHUMANN_NS = 127_713_000;
export const CERTEZA = 0.97;

export type OrganismoApi = {
  cicloVida: (entrada: unknown) => unknown;
  status?: () => unknown;
  traducir?: (src: string, to?: string) => unknown;
  compilar?: (src: string, target?: string) => unknown;
  consultar?: (q: string) => unknown;
  verificar?: (src: string, b: string, la?: string, lb?: string) => unknown;
};

declare global {
  interface Window {
    RIG?: OrganismoApi & Record<string, unknown>;
    RIGADIEL?: Record<string, unknown> & { cicloVida?: OrganismoApi["cicloVida"] };
    RIGADIEL_CICLO?: { cicloVida?: OrganismoApi["cicloVida"]; status?: () => unknown };
    translatePerfect?: (src: string, from: string, to: string) => string;
    ir_to_arm64?: (ir: unknown) => string;
    RigVerifier?: new () => { verify: (...a: unknown[]) => { ok?: boolean } };
  }
}

function installShims() {
  const g = window as unknown as Record<string, unknown>;
  if (!g.process) {
    g.process = {
      hrtime: { bigint: () => BigInt(Date.now()) * 1_000_000n },
      stderr: { write: () => {} },
      exitCode: 0,
      env: {},
    };
  }
}

let loading: Promise<OrganismoApi | null> | null = null;

export function loadOrganismo(): Promise<OrganismoApi | null> {
  if (loading) return loading;
  loading = new Promise((resolve) => {
    installShims();
    if (window.RIG?.cicloVida || window.RIGADIEL_CICLO?.cicloVida) {
      resolve(pickApi());
      return;
    }
    const s = document.createElement("script");
    s.src = "/RIGADIEL_FINAL.js";
    s.async = true;
    s.onload = () => resolve(pickApi());
    s.onerror = () => resolve(null);
    document.head.appendChild(s);
  });
  return loading;
}

function pickApi(): OrganismoApi | null {
  const ciclo =
    window.RIGADIEL_CICLO?.cicloVida ||
    window.RIG?.cicloVida ||
    window.RIGADIEL?.cicloVida;
  if (typeof ciclo !== "function") return null;
  return {
    cicloVida: ciclo,
    status: window.RIGADIEL_CICLO?.status || window.RIG?.status,
    traducir: window.RIG?.traducir,
    compilar: window.RIG?.compilar,
    consultar: window.RIG?.consultar,
    verificar: window.RIG?.verificar,
  };
}

export function dump(value: unknown): string {
  const seen = new WeakSet<object>();
  try {
    return JSON.stringify(
      value,
      (_k, v) => {
        if (typeof v === "bigint") return v.toString();
        if (typeof v === "function") return `[fn ${v.name || "anonymous"}]`;
        if (v instanceof Float32Array || v instanceof Uint8Array || v instanceof Int32Array) {
          return Array.from(v.slice(0, 16));
        }
        if (v && typeof v === "object") {
          if (seen.has(v as object)) return "[circular]";
          seen.add(v as object);
        }
        return v;
      },
      2,
    );
  } catch (e) {
    return String(e);
  }
}

export const SAMPLE_C = `int fib(int n){
  if (n < 2) return n;
  return fib(n-1) + fib(n-2);
}
int main(){
  return fib(10);
}
`;
