export const LANGS: string[];
export const R148: Array<{
  id: string;
  cat: string;
  src: string;
  lang: string;
  dst: string;
  norm: string;
  on: number;
}>;
export const RMAP: Record<string, (typeof R148)[number]>;
export const TESTS: Array<{
  id: string;
  name: string;
  cat: string;
  rids: string[];
  desc: string;
  output: string;
  trace: Array<{ s: number; a: string; d: string }>;
  codes: Record<string, string>;
}>;
export const EXAMPLES: Record<string, string>;
export function translateCode(
  code: string,
  fromLang: string,
  toLang: string,
): { out: string; log: Array<{ rid: string; type: string; rule: unknown; src: string; dst: string }> };
export function safeEval(code: string): { ok: boolean; output: string };
export function parseCode(code: string, lang: string): unknown[];
