# RIGADIEL Studio (comet-pine-crystal-sand)

Aplicación web **RIGADIEL** — un "estudio soberano" construido con **TanStack Start + React 19 + Vite + TailwindCSS 4**. Incluye un motor mecánico de traducción tipo Babel (148 reglas), un núcleo simbólico `organismo` (PHI, Schumann, certezas) compilado a WASM, pestañas de ciclo/traducción/compilación/verificación, autenticación opcional vía better-auth y base de datos PGlite/Postgres con migraciones Kysely.

## Requisitos

- Node.js 20+ (probado con Node 22)
- npm 10+

## Instalación

```bash
npm install
```

## Ejecución (desarrollo)

```bash
npm run dev
```

Levanta el servidor de desarrollo Vite en `http://localhost:8080` (con SSR de TanStack Start).

## Compilación / producción

```bash
npm run build        # build Vite + Nitro + migraciones de BD
npm run preview      # sirve el build
```

La base de datos usa PGlite por defecto (se auto-migra). Con `DATABASE_URL` apuntando a Postgres, `npm run db:migrate` aplica `migrations/`.

## Verificación

```bash
npm run typecheck    # tsc --noEmit
npm run lint         # eslint (0 errores, 0 warnings)
npm test             # 250 tests (node --test)
npm run check:auth   # invariante de autenticación
npm run format       # prettier
```

## Qué se corrigió en esta pasada

1. **8 tests fallando en `scripts/grok-pwa-plugin.test.mjs`**: los tests no eran herméticos; leían `src/lib/og/site.json` ("RIGADIEL") y `public/og.jpg` del repositorio real vía `process.cwd()`, rompiendo la lógica de fallback de `og:title`/`og:image` que probaban. Se aisló cada caso con un `cwd` temporal (`mkdtempSync`), el mismo patrón que ya usaban otros tests del archivo. Resultado: 195/195.
2. **`src/lib/organismo.ts`**: literal `PHI = 1.6180339887498948482` perdía precisión en runtime (`no-loss-of-precision`, error de eslint). Corregido a `1.618033988749895` (el double más cercano a φ) y `SCHUMANN_NS` a separador de guion bajo.
3. **`src/lib/app-data/client.server.ts`**: bloque `catch {}` vacío (`no-empty`). Ahora documenta la intención (fallback al digest del token crudo).
4. **`src/lib/auth/use-current-user.ts`**: directiva `eslint-disable` sin uso. Eliminada.
5. **`eslint.config.mjs`**: se excluyeron del lint los artefactos heredados no fuente (`attachments/`, `public/*.js`, `src/lib/babel/engine.js` con `@ts-nocheck`), que generaban ~3100 errores ajenos a la lógica de la app. El lint del código real queda en **0 errores / 0 warnings**.

## Estructura

- `src/routes/` — rutas TanStack (Studio en `index.tsx`)
- `src/lib/babel/engine.js` — motor de traducción mecánica (148 reglas, extraído de `attachments/babel.txt`)
- `src/lib/organismo.ts` — constantes y API del núcleo simbólico
- `scripts/` — plugin PWA/OG, migraciones, smoke tests y su suite de tests
- `server/middleware/` — chrome PWA/OG para producción (Nitro)
- `attachments/` — bundles JS heredados (RIGCOM master/engine), solo referencia
